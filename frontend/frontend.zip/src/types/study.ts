export interface StudyRoom {
  body: string;
  categoryName: string;
  conversation: string;
  expiredAt: string;
  id: string;
  maxUser: number;
  openAt: string;
  title: string;
}
